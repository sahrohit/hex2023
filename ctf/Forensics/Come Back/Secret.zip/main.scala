object HelloWorld extends App {
    printIn("Hello World")
}